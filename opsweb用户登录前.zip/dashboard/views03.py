from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponse
from django.shortcuts import render


# Create your views here.

def login1(request):
    # get 提交数据
    print("#" * 40)
    print(request.GET)
    print("#" * 40)

    print("lists", request.GET.lists())
    print("#" * 40)

    print("dict", request.GET.dict())
    print("#" * 40)

    user = request.GET.get("user")
    pwd = request.GET.get("pwd")
    print(user, pwd)
    print("#" * 40)
    return render(request, "user/login.html", {"title": "运维平台"})


def login2(request):
    # post提交数据 并同步登录
    print(request.POST)
    user = request.POST.get("user")
    pwd = request.POST.get("pwd")
    print(user)
    print(pwd)

    return render(request, "user/login2.html", {"title": "运维平台"})


def login3(request):
    # ajax 异步登录
    print(request.POST)

    if request.method == "GET":
        return render(request, "user/login3.html", {"title": "运维平台"})
    elif request.method == "POST":
        user = request.POST.get("user", None)
        pwd = request.POST.get("pwd", None)
        print(user)
        print(pwd)
        if user == "admin" and pwd == "123456":
            return HttpResponse("login sucessful")
        else:
            return HttpResponse("login faild")


def login_view(request):
    if request.method == "GET":
        return render(request, "user/login4.html", {"title": "运维平台"})
    elif request.method == "POST":
        username = request.POST.get("user", None)
        password = request.POST.get("pwd", None)
        #验证用户名密码
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                # login(user) 1.8
                # 1.10
                login(request,user)
                return HttpResponse("登录成功")
        else:
            return  HttpResponse("登录失败")


def logout_view(request):
    logout(request)
    return HttpResponse("已退出")