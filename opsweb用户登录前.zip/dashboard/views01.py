
from django.http import HttpResponse,JsonResponse
import json

# Create your views here.

def hello(request):
    return HttpResponse("hi maotai!,世界你好!")


def hello2(request):
    print(request.META)
    print(request.scheme)
    print(request.method)
    return HttpResponse("hi maotai!,世界你好!")


def hello3(request):
    data = {
        'name': "maotai",
        'age': 22,
    }
    #                          告诉浏览器用json格式解析,而我们传的是字典
    return HttpResponse(data, content_type="application/json") #nameage

def hello4(request):
    data = {
        'name': "maotai",
        'age': 22,
    }
    data = json.dumps(data)
    #                          告诉浏览器用json格式解析,我们也传json格式的数据过去
    return HttpResponse(data, content_type="application/json") #nameage

def hello5(request):
    data = {
        'name': "maotai",
        'age': 22,
    }
    data = json.dumps(data)
    #                          告诉浏览器用json格式解析,我们也传json格式的数据过去
    return HttpResponse(data, content_type="application/json",status=400) #nameage

def hello6(request):
    data = {
        'name': "maotai",
        'age': 22,
    }
    # JsonResponse可以序列化字典和列表
    return JsonResponse(data) #nameage
    # return JsonResponse(data,safe=True) #nameage

def hello7(request):
    arr=['lanny','maotai','tutu']
    # JsonResponse可以序列化字典和列表
    return JsonResponse(arr,safe=False) #nameage
