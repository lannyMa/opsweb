#!/usr/bin/env python
# coding=utf-8
from django.conf.urls import url
from . import views
urlpatterns = [

    url(r'^test_form/$', views.test_form),
    url(r'^test_form2/$', views.test_form2),
]
