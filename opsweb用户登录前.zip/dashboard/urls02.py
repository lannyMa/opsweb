#!/usr/bin/env python
# coding=utf-8
from django.conf.urls import url
from . import views
urlpatterns = [
    url(r'^hello/$', views.hello),
    url(r'^login/$', views.login),
    url(r'^login2/$', views.login2),
    url(r'^login3/$', views.login3),
    url(r'^login4/$', views.login4),
    url(r'^login5/$', views.login5),
    url(r'^login6/$', views.login6),
]
