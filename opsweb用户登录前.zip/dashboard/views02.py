from django.http import HttpResponse
from django.shortcuts import render
from django.template import Context,RequestContext, loader, Template,RequestContext



# Create your views here.

def hello(request):
    return HttpResponse("hi maotai!,世界你好!")


def login(request):
    t = Template("<h1>{{ title }}<h1>")
    c = Context({"title": "运维平台"})
    return HttpResponse(t.render(c))


def login2(request):
    t = loader.get_template("user/login.html")
    # c = Context({"title": "运维平台"})
    c = {"title": "运维平台"}
    return HttpResponse(t.render(c))


def login3(request):
    return render(request, "user/login.html", {"title": "运维平台"})


def login4(request):
    # c = Context({"title": "运维平台"})
    c = {"title": "运维平台"}
    content = loader.render_to_string("user/login.html", c, request)
    return HttpResponse(content)

def login5(request):
    # c = Context({"title": "运维平台"})
    c = {"title": "运维平台"}
    content = loader.render_to_string("user/login.html", c)
    return HttpResponse(content)



def login2(request):
    t = loader.get_template("user/login.html")
    c = Context({"title": "运维平台"})
    # c = {"title": "运维平台"}
    return HttpResponse(t.render(c))

def login6(request):
    t = loader.get_template("user/login.html")
    c = RequestContext(request,{"title": "运维平台"})
    # c = Context({"title": "运维平台"})
    return HttpResponse(t.render(c))
