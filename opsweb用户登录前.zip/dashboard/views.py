from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponse, QueryDict
from django.shortcuts import render


# Create your views here.

def test_form(request):
    if request.method=="GET":
        print(request.GET)
        return render(request,"user/test_form.html")
    elif request.method=="POST":
        username = request.POST.get("username","")
        print(request.POST)

        print("*" * 20)
        print(request.POST.lists())
        print(request.POST.dict())
        print("*" * 20)
        print(request.POST)
        fav = request.POST.getlist("fav",[])
        print(username,fav)
        return HttpResponse("提交成功")

def test_form2(request):
    if request.method=="GET":
        print(request.GET)
        print(request.body)
        return render(request,"user/test_form2.html")
    else:
        print("*" * 20)
        print(request.body)
        print(QueryDict(request.body))

        data = QueryDict(request.body)
        print(data.getlist('fav[]'),"")
        return HttpResponse("提交成功")