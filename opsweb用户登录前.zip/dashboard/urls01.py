#!/usr/bin/env python
# coding=utf-8
from django.conf.urls import url
from . import views
urlpatterns = [
    url(r'^hello/$', views.hello),
    url(r'^hello2/$', views.hello2),
    url(r'^hello3/$', views.hello3),
    url(r'^hello4/$', views.hello4),
    url(r'^hello5/$', views.hello5),
    url(r'^hello6/$', views.hello6),
    url(r'^hello7/$', views.hello7),
]
