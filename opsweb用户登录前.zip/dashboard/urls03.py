#!/usr/bin/env python
# coding=utf-8
from django.conf.urls import url
from . import views
urlpatterns = [

    url(r'^login1/$', views.login1),
    url(r'^login2/$', views.login2),
    url(r'^login3/$', views.login3),
    url(r'^login_view/$', views.login_view),
    url(r'^logout_view/$', views.logout_view),
]
